package day18;

public interface Animal {
String Category = "Living Beign";
        static boolean IsMammal(String Animal) {
			if (Animal.equalsIgnoreCase("dog")||(Animal.equalsIgnoreCase("cat"))||(Animal.equalsIgnoreCase("human"))){
				return true;
			}
        	
			else {
				return false;
			}
}
	public default void speak(){
		System.out.println("Animal is making a sound");
	}
  	abstract void move();
		
	}

