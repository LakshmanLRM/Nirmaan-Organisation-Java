package day18;

import java.util.Scanner;

public class Testing {

	public static void main(String[] args) {
       Scanner sc=new Scanner(System.in);
       System.out.println("Enter the name");
       String in= sc.nextLine();
       System.out.println(Animal.IsMammal(in));
       Dog d =new Dog();
       Bird b = new Bird();
       d.move();
       d.speak();
       b.move();
       b.speak();
       System.out.println(Animal.Category);
	}

}
