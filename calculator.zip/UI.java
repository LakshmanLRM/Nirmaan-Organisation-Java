package day10;

import java.util.Scanner;

public class UI {
	public static void main(String[] args) {
		calculator cal=new calculator();
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the first number");
		int num1=sc.nextInt();
		System.out.println("enter the seond number");
		int num2=sc.nextInt();
		cal.add(num1, num2);
	    cal.Sub(num1, num2);
	    cal.Multiplication(num1, num2);
	    cal.Division(num1, num2);
	    cal.Modulous(num1, num2);
	}

}
