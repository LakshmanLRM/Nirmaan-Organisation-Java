package day10;

public class calculator {
 void add(int num1,int num2){
	 System.out.println("Addiion:"+(num1+num2));
	
 }
 void Sub(int num1,int num2){
	 System.out.println("Sub:"+(num1-num2));
	
 }
 void Multiplication(int num1,int num2){
	 System.out.println("Multiplication:"+(num1*num2));
	
 }
 void Division(int num1,int num2){
	 System.out.println("Division:"+(num1/num2));
	
 }void Modulous(int num1,int num2){
	 System.out.println("Modulous:"+(num1%num2));
	
 }
	}

