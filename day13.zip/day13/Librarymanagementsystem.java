package day13;

import java.util.Scanner;

public class Librarymanagementsystem {
 private int id;
 private String bookname;
 private String bookauthor;
 private int price;
 
	public int getId() {
	return id;
}

public void setId(int id) {
	this.id = id;
}

public String getBookname() {
	return bookname;
}

public void setBookname(String bookname) {
	this.bookname = bookname;
}

public String getBookauthor() {
	return bookauthor;
}

public void setBookauthor(String bookauthor) {
	this.bookauthor = bookauthor;
}

public int getPrice() {
	return price;
}

public void setPrice(int price) {
	this.price = price;
}
@Override
public String toString() {
	return "Librarymanagementsystem [id=" + id + ", bookname=" + bookname + ", bookauthor=" + bookauthor + ", price="
			+ price + "]";
}
public static void main(String[] args) {
Librarymanagementsystem lm = new Librarymanagementsystem();
Scanner sc = new Scanner(System.in);
boolean stop =true;
while(stop) {
	System.out.println("1.posting books");
	System.out.println("2.update books");
	System.out.println("3.show books");
	System.out.println("4.ext library");
	int key =sc.nextInt();
	switch(key) {
	
	}
}

}

}
