package day13;

public class UI {
private int rollno;
private String name;
 public UI(int rollno,String name) {
	  this.rollno=rollno;
	  this.name=name;
 }
 public int getId() {
	 return rollno;
 }
 public void SetId(int rollno ) {
	 this. rollno = rollno;
 }
 public String getname() {
	 return name;
 }
 public void Setname(String name ) {
this. name = name;
 }
 
	public static void main(String[] args) {


}
}