package student.management.system;

import java.util.Scanner;
import java.util.TreeSet;

public class userinterfce {
 public static void main(String []args) { 
	 Scanner sc=new Scanner(System.in);
	 studentservice ss=new studentservice();
	 TreeSet<Student>ts=new TreeSet<Student>();
	 while(true) {
		 System.out.println("1.addstudent:\n2.Getallstudent:\n3.get one student:\n4.updatestudent:\n5.Deletstudent");
		 int Key=sc.nextInt();
		 if(Key==1) {
			ts.add( ss.addStudent());
			 
		 }else if(Key==2) {
			 ss.getstudent(ts);
		 }else if(Key==3){
			 System.out.println(ss.getStudentById(ts));
		 }else if(Key==4) {
		    ss.updateStudent(ts);
		 }else if(Key==5) {
			 ss.deleteStudent(ts);
		 }
		 else {
			 System.out.println("Enter crct code");
		 }
	 }
 }
}
