package student.management.system;

public class Student implements Comparable<Student>{
        private int id;
        private int rollno;
        private String name;
        private float fees;
        
		
		public Student(int id, int rollno, String name, float fees) {
			super();
			this.id = id;
			this.rollno = rollno;
			this.name = name;
			this.fees = fees;
		}
		
		public Student() {
			super();
		}

		@Override
		public String toString() {
			return "student [id=" + id + ", rollno=" + rollno + ", name=" + name + ", fees=" + fees + "]";
		}
		public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		public int getRollno() {
			return rollno;
		}
		public void setRollno(int rollno) {
			this.rollno = rollno;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public float getFees() {
			return fees;
		}
		public void setFees(float fees) {
			this.fees = fees;
		}

		@Override
		public int compareTo(Student stu) {
        if(this.id<stu.getId()) {		
		return -1;
		}
        else if(this.id>stu.getId()) {		
    		return 1;
    		}
       
        else {return 0;}
		}
	
}
