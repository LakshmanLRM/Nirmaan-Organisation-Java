package student.management.system;

import java.util.Scanner;
import java.util.Set;

public class studentservice implements IStudentservice{
	Scanner sc=new Scanner(System.in);
	@Override
	public Student addStudent() {
		
		  System.out.println("Enter the student id");
		     int id =sc.nextInt();
		     System.out.println("Enter the student rollno");
		     int rollno=sc.nextInt();
		     sc.nextLine();
		     System.out.println("Enter the name");
		     String name=sc.nextLine();
		     System.out.println("Enter the fees");
		     float fees=sc.nextFloat();
					return new Student(id, rollno, name, fees);
	}

	@Override
	public void getstudent(Set<Student> Set) {
      System.out.println(Set);	
	}

	@Override
	public Student getStudentById(Set<Student> Set) {
        System.out.println("Enter studentid");
        int Key=sc.nextInt();
        for(Student std:Set)
        	if(std.getId()==Key) {
        		return std;	
        	}
		
		return null;
	}

	@Override
	public Set<Student> updateStudent(Set<Student> Set) {
		 System.out.println("Enter studentid");
	        int Key=sc.nextInt();
	        for(Student std:Set) {
	        	if(std.getId()==Key) {
	        		System.out.println("Enter the student rollno");
	   		     int rollno=sc.nextInt();
	   		     std.setRollno(rollno);
	   		     sc.nextLine();
	   		     System.out.println("Enter the name");
	   		     String name=sc.nextLine();
	   		     std.setName(name);
	   		     System.out.println("Enter the fees");
	   		     float fees=sc.nextFloat();
	   		     std.setFees(fees);
	        		return Set;	
	        	}}
	        return null;
	}

	@Override
	public Set<Student> deleteStudent(Set<Student> Set) {
		 System.out.println("Enter studentid");
		 int Key=sc.nextInt();
	        for(Student std:Set)
	        	if(std.getId()==Key) {
	        		return Set;	
	        		
	}
	
	return null;	 

	
	}
           
}