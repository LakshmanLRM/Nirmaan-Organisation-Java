package student.management.system;

import java.util.Set;

public interface IStudentservice {
     public Student addStudent();
     public void getstudent(Set<Student>Set);
     public Student getStudentById(Set<Student>Set);
     public Set<Student> updateStudent(Set<Student>Set);
     public Set<Student> deleteStudent(Set<Student>Set);
	
}
